package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	/**
	 * Generates a SHA-256 checksum (hash) of a fixed data string and returns it
	 * along with the original data. This endpoint demonstrates a data
	 * verification step that Artemis Financial can use to confirm that data
	 * has not been altered in transit.
	 *
	 * Accessible at https://localhost:8443/hash once the server is running
	 * with HTTPS enabled.
	 */
	@GetMapping("/hash")
	public String hash() {
		// Unique data string: replace with your own name/identifier as needed
		String data = "Sean Singh checksum verification";
		String hashedData;

		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(data.getBytes("UTF-8"));
			StringBuilder hexString = new StringBuilder();

			for (byte b : hash) {
				String hex = Integer.toHexString(0xff & b);
				if (hex.length() == 1) {
					hexString.append('0');
				}
				hexString.append(hex);
			}

			hashedData = hexString.toString();
		} catch (Exception e) {
			hashedData = "Error occurred while generating the hash: " + e;
		}

		return "Data: " + data + "<br>Hash: " + hashedData;
	}

}
